import {
  READ_SETTINGS,
  SET_BOOLEAN_OPTION
} from '../actions/settings';

const initialState = {

};

export default function SettingsReducer(state=initialState, action) {
  switch(action.type) {
    case READ_SETTINGS:
    return Object.assign({}, action.payload);
    case SET_BOOLEAN_OPTION:
    return Object.assign({}, state, {
      [`${action.payload.option}`]: action.payload.state
    });
    default:
    return state;
  }
}
