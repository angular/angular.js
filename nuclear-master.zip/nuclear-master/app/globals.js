module.exports = {
  ytApiKey: "AIzaSyCIM4EzNqi1in22f4Z3Ru3iYvLaY8tc3bo",
  lastfmApiKey: "2b75dcb291e2b0c9a2c994aca522ac14",
  lastfmApiSecret: "2ee49e35f08b837d43b2824198171fc8",
  soundcloudApiKey: "I49FIxeHiQfMWdhxi0pI7MjiV210nFx6"
};
