export default class Plugin {
  constructor() {
    this.name = 'Plugin';
    this.description = 'A generic plugin class. Should never be instantiated.';
    this.image = null;
  }
}
