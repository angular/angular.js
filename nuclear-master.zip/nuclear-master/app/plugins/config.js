import * as MusicSourcePlugins from './MusicSources/';

export const config = {
  plugins: {
    musicSources: MusicSourcePlugins
  }
};
