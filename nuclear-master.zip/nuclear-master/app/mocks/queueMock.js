export const queueData = [
    {
      thumbnail: "https://classicalbumcovers.files.wordpress.com/2013/03/black_sabbath-vol_4.jpg",
      artist: "Black Sabbath",
      name: "Supernaut"
    },
    {
      thumbnail: "https://upload.wikimedia.org/wikipedia/en/9/9a/Zappa_Joe%27s_Garage.jpg",
      artist: "Frank Zappa",
      name: "Joe's Garage"
    },
    {
      thumbnail: "http://3.bp.blogspot.com/_aNTsUIQhmf0/TJD02nFCD0I/AAAAAAAADyc/nEs2_ttp98c/s1600/Neutral+Milk+Hotel+-+In+the+Aeroplane+Over+the+Sea+-+1998.jpg",
      artist: "Neutral Milk Hotel",
      name: "The King of Carrot Flowers Pts. Two & Three"
    },
  ];
